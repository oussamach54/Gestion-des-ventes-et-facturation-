package com.example.salesmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesMasterApplicationTests {

    @Test
    void contextLoads() {
    }

}
